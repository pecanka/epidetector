#./EpiDetector --test 1 --pretest 4 --model A --bfile \
#  alz_apoe_recoded_subset --submap RS_MDR_selected.submap --level1 1 --nthreads 16 \
#  --tempcycle 400000 --delta 0.5 --nocountdown --mincellcount 0 \
#  --cellcorrection 1 --reportdisjoint --reportscore --reportall --alwaysscore \
#  --rejectall --non-grouped-variance --center-by-self --random-subsample

call="./EpiDetector --simulateinput --test 1 --pretest 3 --amodel I --smodel I --fixedmaf --maf1 0.35 --maf2 0.35 --maf3 0.35
                    --delta auto-simple --delta-simple-frac 1 --OR-min 1.00 --OR-max 3 --OR-step 0.1 --nrepeats max
                    --nloci 2 --ncases 1000 --ncontrols 25000 --nsamples 500 --prevalence 0.01 --OR1 1 --OR2 1 --LD 0.5
                    --mincellcount 0 --cellcorrection 1 --reportdisjoint --reportscore --reportall --alwaysscore --rejectall --out-minimalistic
                    --ndigit-pval 1 --hide-errors --nocountdown --center-group 1 --group-var --group-cov 
                    --max-runtime-s -1501"

call="./EpiDetector --simulateinput --test 1 --pretest 3 --amodel A 
  --smodel A --fixedmaf --maf1 0.35 --maf2 0.35 --maf3 0.35 --delta-min 0.05 
  --delta-max 0.95 --delta-step 0.05 --OR-min 1 --OR-max 3.1 --OR-step 0.1 
  --nrepeats max --nloci 2 --ncases 2000 --ncontrols 11000 --nsamples 4000 
  --prevalence 0.01 --OR1 1.0 --OR2 1.0 --mincellcount 0 --cellcorrection 1 
  --reportdisjoint --reportscore --reportall --alwaysscore --rejectall 
  --out-minimalistic --ndigit-pval 1 --hide-errors --nocountdown 
  --max-runtime-s 70200 --HWE"
eval $call
if [[ ! ( $? == 0 ) ]]; then echo -e "\nERROR: Unclean exit from EpiDetector.\n"; exit; fi
echo "Clean exit from EpiDetector."
exit
                              
if false; then
  ./EpiDetector --simulateinput --test 1 --pretest 3 --amodel A \
    --smodel A --fixedmaf --maf1 0.35 --maf2 0.35 --maf3 0.35 --delta auto-simple \
    --OR-min 1 --OR-max 1 --OR-step 0.1 \
    --nrepeats max --nloci 2 --ncases 500 --ncontrols 1100 --nsamples 100 \
    --prevalence 0.01 --OR1 1.0 --OR2 1.0 --LD 0.1 --mincellcount 0 \
    --cellcorrection 1 --reportdisjoint --reportscore --reportall --alwaysscore \
    --rejectall --out-minimalistic --ndigit-pval 1 --hide-errors --nocountdown \
    --center-group 1 --group-var --group-cov --level1 1 --save-ped
else 
  ./EpiDetector --simulateinput --test 1 --pretest 3 --amodel A \
    --smodel A --fixedmaf --maf1 0.35 --maf2 0.35 --maf3 0.35 --delta auto-simple \
    --OR-min 1.00 --OR-max 3.0 --OR-step 0.1 --nrepeats max --nloci 2 --ncases \
    2000 --ncontrols 7000 --nsamples 500 --prevalence 0.01 --OR1 1 --OR2 1 --LD \
    -0.05 --mincellcount 0 --cellcorrection 1 --reportdisjoint --reportscore \
    --reportall --alwaysscore --rejectall --out-minimalistic --ndigit-pval 1 \
    --hide-errors --nocountdown --center-group 1 --group-var --group-cov \
    --max-runtime-s 3600 --delta-simple-frac 0.5 --save-ped
fi  
  