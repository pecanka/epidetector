my $level=0.0001;
my $correct = 100000000;
my $delta = 0.1;
my $pretest = 2;
system("EpiDetector.exe --disjoint --ped EPIC.simulated.LEloci=0.LDloci=0.n=1000.RR=1.5.RR1=1.RR2=1.LD=0.AlleleF=0.27.Prev=0.01.ped --pretest ".$pretest." --delta ".$delta." --level1 ".$level." --samechr --samplesize 2000 --correct1 ".$level*$correct." --correct2 ".$correct);
