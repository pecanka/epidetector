library(mgcv)
library(corpcor)

GetVar = function(PQ,p,q,mp2,mq2){

    V = matrix(NA,nrow=9,ncol=9)
    
    for(k in 1:3){
    for(l in 1:3){
    for(r in 1:3){
    for(s in 1:3){
    
        if(k==r & l==s) {
          V[3*(k-1)+l,3*(r-1)+s] = ( PQ[k,l]*(1-PQ[k,l]) - 2*p[k]*PQ[k,l]*(1-q[l]) 
                             - 2*q[l]*PQ[k,l]*(1-p[k]) 
                             + 2*p[k]*q[l]*(PQ[k,l]-p[k]*q[l]) 
                             + p[k]*p[k]*q[l]*(1-q[l]) 
                             + q[l]*q[l]*p[k]*(1-p[k])) / (mp2[k]*mq2[l])
        } else if(k==r & l!=s) {
          V[3*(k-1)+l,3*(r-1)+s] = ( -PQ[k,l]*PQ[k,s] + p[k]*PQ[k,s]*q[l] 
                             + p[k]*PQ[k,l]*q[s] - q[l]*PQ[k,s]*(1-p[k]) 
                             - q[s]*PQ[k,l]*(1-p[k]) 
                             + p[k]*q[l]*(PQ[k,s]-p[k]*q[s]) 
                             + p[k]*q[s]*(PQ[k,l]-p[k]*q[l]) 
                             - p[k]*p[k]*q[l]*q[s] + q[l]*q[s]*p[k]*(1-p[k]) ) / sqrt(mp2[k]*mp2[r]*mq2[l]*mq2[s])
        } else if(k!=r & l==s) {
          V[3*(k-1)+l,3*(r-1)+s] = ( -PQ[k,l]*PQ[r,l] - p[k]*PQ[r,l]*(1-q[l]) 
                             - p[r]*PQ[k,l]*(1-q[l]) + p[k]*PQ[r,l]*q[l] 
                             + p[r]*PQ[k,l]*q[l] +p[r]*q[l]*(PQ[k,l]-p[k]*q[l])
                             + p[k]*q[l]*(PQ[r,l]-p[r]*q[l]) 
                             + p[k]*p[r]*q[l]*(1-q[l]) - q[l]*q[l]*p[k]*p[r]) / sqrt(mp2[k]*mp2[r]*mq2[l]*mq2[s])
        } else {
          V[3*(k-1)+l,3*(r-1)+s] = ( -PQ[k,l]*PQ[r,s] + 2*p[k]*PQ[r,s]*q[l] 
                             + 2*p[r]*PQ[k,l]*q[s] 
                             + p[r]*q[l]*(PQ[k,s]-p[k]*q[s])
                             + p[k]*q[s]*(PQ[r,l]-p[r]*q[l]) 
                             - 2*p[k]*p[r]*q[l]*q[s] ) / sqrt(mp2[k]*mp2[r]*mq2[l]*mq2[s])
        }
    }}}}
    
    return(V)
}

#beta = matrix(c(0.02,-0.03,0.05,5),nrow=1)
beta = matrix(c(0.0,-0.01,0.5,1),nrow=1)

#beta=read.table("pair_beta.txt", header=F)
#beta=as.numeric(beta)
#beta = c(beta,10)

k = c(rep(0,3),rep(1,3),rep(2,3))
l = c(0:2,0:2,0:2)

KL = rbind(rep(1,9),k,l,k*l)
Phi = -beta%*%KL[1:length(beta),]
Phi = 1/(1+exp(Phi))

p=read.table("pair_P_all.txt", header=F)
p=as.numeric(p)
p=as.vector(t(matrix(p,nrow=3)))
#p = runif(9,0.1,0.5)
#p = p/sum(p)



pikl = matrix(p,nrow=3,ncol=3)
pik = matrix(apply(pikl,1,sum),ncol=1)
pil = matrix(apply(pikl,2,sum),ncol=1)
#pikl = pik%*%t(pil)

tau = sum(as.vector(t(pikl))*(1-Phi))

Pkl = 1/tau*pikl*matrix(1-Phi,nrow=3,ncol=3,byrow=T)
Rkl = 1/(1-tau)*pikl*matrix(Phi,nrow=3,ncol=3,byrow=T)
Pkl = Pkl/sum(Pkl)
Rkl = Rkl/sum(Rkl)

pk = apply(Pkl,1,sum)
ql = apply(Pkl,2,sum)
rk = apply(Rkl,1,sum)
sl = apply(Rkl,2,sum)

p2 = rep(1,3)
q2 = rep(1,3)

V1 = GetVar(Pkl,pk,ql,p2,q2)
V2 = GetVar(Rkl,rk,sl,p2,q2)

V = V1 + V2

V.inv = pseudoinverse(V)
V.spectral = eigen(V.inv)
V.e = V.spectral$va
V.v = V.spectral$ve
V.sqinv = V.v%*%diag(sqrt(abs(V.e)))%*%t(V.v)

PQ = ((Pkl - pk*ql) - (Rkl - rk*ql))
delta = matrix(as.vector(PQ),ncol=1)
lambda = sum(abs(V.sqinv%*%delta)^2)
print(lambda)
