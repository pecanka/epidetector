setwd("D:\\FTP\\_CurrentWork\\EpiDetector_openmp\\")
#setwd("D:\\_CurrentWork\\EpiDetector_openmp\\")
#x=read.table("chr1.dat_output.epi")
#x=read.table("chr22nscs.recode2.ped_output.epi")
#x=read.table("EPIC.simulated.loci=200.n=2000.rr=1.ld=0.ped_output.epi", header=T)
#x=read.table("EPIC.simulated.loci=200.n=1000.rr=1.ld=0.ped_output.epi", header=T)
#x=read.table("EPIC.simulated.loci=200.n=500.rr=1.ld=0.ped_output.epi", header=T, na.strings="*")
x=read.table("EPIC.simulated.loci=200.n=2000.RR=1.LD=0.ped_output_pretest=2_test=1_level1=0.1_delta=0.5_1.epi", header=T, na.strings="*")

as=x[I(x[,2]!=0),2]
s=x[I(x[,5]!=0),5]
t=x[I(x[,8]!=0),8]
p=x[I(x[,9]!=0),9]

st = t[I(p<0.1)]

print(mean(as))
print(var(as))
hist(as)
print(shapiro.test(as))

library(nortest)
print(lillie.test(as))
