prob.alpha = function(lambda,alpha,n0,n1,power.bound,h,k){
    l=1:n0
    power.fun = 1-pchisq(qchisq(1-alpha,k),h,lambda)
    sumand = choose(n0,l)*power.fun^l*(1-power.fun)^(n0-l)
    p=sum(sumand[n1:n0])
    p = (p-power.bound)^2
    return(p)
}

getbounds.lambda = function(alpha,n0,n1,power.bound,h,k){
    eps = 10^(-3)
    l=1:n0
    p = 0
    lambda = 0
    while(p<power.bound){
        lambda.prev = lambda
        lambda = lambda+1
        power.fun = 1-pchisq(qchisq(1-alpha,k),h,lambda)
        sumand = choose(n0,l)*power.fun^l*(1-power.fun)^(n0-l)
        p=sum(sumand[n1:n0])
    }
    return(c(lambda.prev,lambda))
}

prob.lambda = function(alpha,lambda,n0,n1,power.bound,h,k){
    l=1:n0
    power.fun = 1-pchisq(qchisq(1-alpha,k),h,lambda)
    sumand = choose(n0,l)*power.fun^l*(1-power.fun)^(n0-l)
    p=sum(sumand[n1:n0])
    p = (p-power.bound)^2
    return(p)
}

getbounds.alpha = function(lambda,n0,n1,power.bound,h,k){
    alpha = 10^(-12)
    l=1:n0
    p = 0
    i=0
    while(p<power.bound & alpha<0.5){
        i=i+1
        alpha.prev = alpha
        alpha = min(0.5,alpha*10)
        power.fun = 1-pchisq(qchisq(1-alpha,k),h,lambda)
        sumand = choose(n0,l)*power.fun^l*(1-power.fun)^(n0-l)
        p=sum(sumand[n1:n0])
    }
    return(c(alpha.prev,alpha))
}
    
k = 4
h = 4

#######################

power.bound = 0.5
n1 = seq(5,100,by=5)
n0 = rep(100,length(n1))

#alpha = c(0.2,0.15,0.1,0.05,0.02,0.01,0.005,0.001,0.0005,0.0001,0.00005,0.00001,0.000005,0.000001,0.0000005,0.0000001,0.00000005,0.00000001)
alpha = 0.1^(1:10)
for(j in 1:length(n1)){
    results = NULL
    power = NULL
    for(i in 1:length(alpha)){
        bounds = getbounds.lambda(alpha[i],n0[j],n1[j],power.bound,h,k)
        opt = optimize(prob.alpha, interval=bounds,alpha[i],n0[j],n1[j],power.bound,h,k, tol=.Machine$double.eps)
        results = c(results,opt$minimum)
        power = c(power,opt$objective+power.bound)
    }
    title = "Minimal lambda given alpha"
    if(j==1) plot(results,col=j,ylim=c(0,105),xlim=c(1,10),type="l",main=title,xlab="-log(alpha,10)",ylab="lambda")
    if(j>1) lines(results,col=j)
}
legend("topleft", legend=n1, ncol=3, col = 1:length(n1), lty = 1, pch = -1, cex=0.8, merge = F)

#######################

#power.bound = 0.5
#
#n1 = seq(5,100,by=5)
#n0 = rep(100,length(n1))
#
#lambda = seq(1,30,by=1)
#for(j in 1:length(n1)){
#    results = NULL
#    power = NULL
#    for(i in 1:length(lambda)){
#        bounds = getbounds.alpha(lambda[i],n0[j],n1[j],power.bound,h,k)
#        opt = optimize(prob.lambda, interval=bounds,lambda[i],n0[j],n1[j],power.bound,h,k, tol=.Machine$double.eps)
#        results = c(results,opt$minimum)
#        power = c(power,opt$objective+power.bound)
#    }
#    results=-log(results,10)
#    #title = paste("Minimal alpha (order) given lambda for the power to exceed",power.bound)
#    title = "Minimal alpha (order) given lambda"
#    if(j==1) plot(results,col=j,ylim=c(0,12),type="l",main=title,xlab="lambda",ylab="-log(alpha,10)")
#    #if(j==1) plot(results~lambda,ylim=c(0,0.15),col=j,type="l",main=title)
#    if(j>1) lines(results~lambda,col=j)
#}
#legend("topleft", legend=n1, ncol=3, col = 1:length(n1), lty = 1, pch = -1, cex=0.8, merge = F)

#######################

#print("results")
#print(results)
#print("power")
#print(power)
