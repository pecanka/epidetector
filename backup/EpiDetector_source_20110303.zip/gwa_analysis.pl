#!/usr/bin/perl

sub round {
    my($number) = shift;
    return int(100*($number + .5))/100;
}

my $n1=1;
my $n2=250;
my $nchr=2;
my $schr=6;

my $dosimul = 1;
my $doepi = 1;
my $doanalysis = 1;

#my $controlfile="control_fullnull_10chr_3000.dat";
#my $controlfile="control_fullnull_5chr_100.dat";
#my $controlfile="control_fullnull_10chr_500.dat";
#my $controlfile="control_fullnull_2chr_400.dat";
my $controlfile="control_fullnull_2chr_200_small.dat";

for my $j ($n1..$n2){
  
  if($dosimul==1){
    $rn = rand();
    $rn = int(10000000*$rn);
    system("GWAsimulator.exe ".$controlfile." ".$rn);
    system("md simul");
    system("md simul\\".$j);
    for my $i($schr..($schr+$nchr-1)){
      system("move chr".$i.".dat.gz simul\\".$j."\\chr".$i.".dat.gz");
    }
  
   	open(PFILE,">simul\\".$j."\\list.ped") || die "Can't open pedfile\n";
    for my $i($schr..($schr+$nchr-1)){
      print PFILE "chr".$i.".dat";
      print PFILE "\n"; 
    }
    close PFILE;
  }
  
  if($doepi==1){
    print "Unzipping data files ...\n";
    system("gzip -d -k simul\\".$j."\\chr*.dat.gz");
    print "All data files unzipped\n";
    my $command = "EpiDetector.exe --silent --pedlist simul\\".$j."\\list.ped --samechr --pretest 2 --level1 0.25";
    print $command."\n";
    system($command);
    system("del simul\\".$j."\\*.dat /Q");
    system("del simul\\".$j."\\*.gz /Q");
  }
 
  if($doanalysis==1){
   	#open(PFILE,">","outputlist.epi") || die "Can't open pedfile\n";
    #for my $i($n1..$j){
    #  print PFILE $i."\\chr".$i.".dat_output.epi";
    #  print PFILE "\n"; 
    #}
    #close PFILE;
    system("EPIdetector.exe --runanalysis --results simul\\".$j."\\chr1.dat_output.epi");
  }
}